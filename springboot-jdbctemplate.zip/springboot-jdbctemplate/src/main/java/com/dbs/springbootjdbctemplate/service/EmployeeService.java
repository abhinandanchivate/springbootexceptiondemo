package com.dbs.springbootjdbctemplate.service;


import java.util.List;
import java.util.Optional;

import com.dbs.springbootjdbctemplate.dto.Employee;
import com.dbs.springbootjdbctemplate.exceptions.EntityNotFoundException;

public interface EmployeeService {
	public Employee createEmployee(Employee employee);
    public Employee deleteEmployee(int i);
    public Employee updateEmployee(String empId, Employee employee);
    public Employee getEmployeeById(int empId) throws EntityNotFoundException ;
    public Optional<List<Employee>> getEmployees();
    public Optional<List<Employee>> getEmployeesByLastName(String lastName);

    public void deleteAll();
    public Optional<Employee> getEmployeesByIdAndLastName(int empId,String lastName);
}
