package com.dbs.springbootjdbctemplate.exceptions;

public class EntityNotFoundException extends Exception {
	
	public EntityNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
}
