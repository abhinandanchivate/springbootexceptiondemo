package com.dbs.springbootjdbctemplate.service;

import java.util.List;
import java.util.Optional;

import com.dbs.springbootjdbctemplate.dto.Department;

public class DepartmentServiceImpl implements DepartmentService {

	@Override
	public Department createDepartment(Department Department) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Department deleteDepartment(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Department updateDepartment(String deptId, Department Department) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Department> getDepartmentById(int deptId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Department>> getDepartments() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Department>> getDepartmentsByLastName(String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Department> getDepartmentsByIdAndLastName(int deptId, String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

}
