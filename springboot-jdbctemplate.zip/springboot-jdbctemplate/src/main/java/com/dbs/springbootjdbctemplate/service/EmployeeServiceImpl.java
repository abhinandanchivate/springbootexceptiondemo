package com.dbs.springbootjdbctemplate.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.dbs.springbootjdbctemplate.dto.Employee;
import com.dbs.springbootjdbctemplate.exceptions.EntityNotFoundException;
import com.dbs.springbootjdbctemplate.repository.EmployeeRepository;


@Service
@Scope() // prototype scope will give different object
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public Employee createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

	@Override
	public Employee deleteEmployee(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee(String empId, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmployeeById(int empId) throws EntityNotFoundException {
		// TODO Auto-generated method stub
		
		Optional<Employee> optional = employeeRepository.findById(empId);
		
		if(optional.isPresent()) {
			return optional.get();
		}
		else {
			//optional.orElseThrow(()->new EntityNotFoundException("record not found"));
		throw new EntityNotFoundException("record not found");
		}
	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub
	List<Employee> employees= employeeRepository.findAll();
	
	if(employees.isEmpty()) {
		return Optional.empty();
	}
	else return Optional.of(employees);
	}

	@Override
	public Optional<List<Employee>> getEmployeesByLastName(String lastName) {
		// TODO Auto-generated method stub
		return employeeRepository.findByEmpLastName(lastName);
	}

	@Override
	public Optional<Employee> getEmployeesByIdAndLastName(int empId, String lastName) {
		// TODO Auto-generated method stub
		return employeeRepository.findByEmpIdAndEmpLastName(empId, lastName);
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
	
		employeeRepository.deleteAll();
		
	}
	
	

	
	

}
