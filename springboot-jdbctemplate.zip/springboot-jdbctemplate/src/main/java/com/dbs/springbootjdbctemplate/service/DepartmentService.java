package com.dbs.springbootjdbctemplate.service;

import java.util.List;
import java.util.Optional;

import com.dbs.springbootjdbctemplate.dto.Department;

public interface DepartmentService {
	
	public Department createDepartment(Department Department);
    public Department deleteDepartment(int i);
    public Department updateDepartment(String deptId, Department Department);
    public Optional<Department> getDepartmentById(int deptId);
    public Optional<List<Department>> getDepartments();
    public Optional<List<Department>> getDepartmentsByLastName(String lastName);

    public Optional<Department> getDepartmentsByIdAndLastName(int deptId,String lastName);

}