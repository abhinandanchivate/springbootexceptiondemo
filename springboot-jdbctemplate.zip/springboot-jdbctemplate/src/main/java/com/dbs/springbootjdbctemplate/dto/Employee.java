package com.dbs.springbootjdbctemplate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

@Entity
@Table(name = "employeetbl")
@AllArgsConstructor

@NoArgsConstructor

public class Employee implements Serializable {
	@Id
	@Column(name = "emp_id")
	@Min(1)
	@Max(100000)
	private int empId;
	@NotNull
	@javax.validation.constraints.NotBlank
	private String empFirstName;
	@NotNull
	@javax.validation.constraints.NotBlank
	private String empLastName;
	//private String address;
	@javax.validation.constraints.NotNull
	private float empSalary;
	

}
