package com.dbs.springbootjdbctemplate.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.springbootjdbctemplate.dto.Employee;
import com.dbs.springbootjdbctemplate.exceptions.EntityNotFoundException;
import com.dbs.springbootjdbctemplate.service.EmployeeService;

@RestController
// @ResponseEntity : it will take care for handling the response.
// by default it will return the stuff in a json format.
// @controller : will handle the controlling work for ur application

@RequestMapping("/employee") // here it will apply the controller level mapping 
// this approach will help us to separate the stuff.

public class EmployeeController {

	// controller should talk to Service
	@Autowired
	EmployeeService employeeService;
	@GetMapping("/test")
	public String test() {
		return "test";
	}
	
	// add the new employee record
	@PostMapping("/create")  // json to java object 
	public ResponseEntity<?> addEmployee( @RequestBody @Valid Employee employee) throws EntityNotFoundException {
		// response entity is responsible for sending teh response to client.
		
	
			//Employee employee3 = employeeService.getEmployeeById(employee.getEmpId());
			Employee employee2 =  employeeService.createEmployee(employee);
			if(employee2!=null)
			return ResponseEntity.status(201).body(employee);
			else return ResponseEntity.status(400).body("details are not proper");
		
		
		
		
		
			
		// we should return status code 201
		// failure 400 bad req. 404 something. 
		// java object to JSON.
	}
	@GetMapping("/{id}")
	public ResponseEntity<?> getEmployeeById(@PathVariable("id") int id) throws EntityNotFoundException {
		
		Employee employee = employeeService.getEmployeeById(id);
		
		
			return ResponseEntity.status(200).body(employee);
		
		
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteById(@PathVariable int id) {
		
	
		Employee employee =  employeeService.deleteEmployee(id);
		
		if(employee!=null)
			return ResponseEntity.status(204).body("record deleted successfully");
		else
			return ResponseEntity.status(404).body("record not found");
	}
	
	@DeleteMapping
	public void deleteAll() {
		employeeService.deleteAll();
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAllEmployees(){
Optional<List<Employee>> optional =  employeeService.getEmployees();
		
		if(optional.isPresent())
			return ResponseEntity.status(200).body(optional.get());
		else
			return ResponseEntity.noContent().build();
	}
	
	
}
