package com.dbs.springbootjdbctemplate.advice;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.dbs.springbootjdbctemplate.apierror.ApiError;
import com.dbs.springbootjdbctemplate.exceptions.EntityNotFoundException;

// can we have multiple controllers? 
// RecordNotFoundException may be raised multiple times 
// action on it would be common
// so to write that common action we will use advice based classes.
@ControllerAdvice
public class EmployeeControllerAdvice extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(EntityNotFoundException.class)
	protected ResponseEntity<Object> handleNotFoundEntity(EntityNotFoundException ex){
		
		ApiError apiError = new ApiError(HttpStatus.NOT_FOUND);
		apiError.setMessage(ex.getMessage());
		return buildResponseEntity(apiError);
		
	}
	
	private ResponseEntity<Object> buildResponseEntity(ApiError apiError){
		return new ResponseEntity<>(apiError,apiError.getStatus());
	}
	
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		 ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST);
	        apiError.setMessage("Validation error");
	        apiError.addValidationErrors(ex.getBindingResult().getFieldErrors());
	        apiError.addValidationError(ex.getBindingResult().getGlobalErrors());
	        return buildResponseEntity(apiError);
	}

	protected ResponseEntity<Object> handleConstraintViolation(javax.validation.ConstraintViolationException ex){
		   ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST);
		   System.out.println(apiError.toString());
	        apiError.setMessage("Validation error");
	        apiError.addValidationErrors(ex.getConstraintViolations());
	        return buildResponseEntity(apiError);
	}

}
