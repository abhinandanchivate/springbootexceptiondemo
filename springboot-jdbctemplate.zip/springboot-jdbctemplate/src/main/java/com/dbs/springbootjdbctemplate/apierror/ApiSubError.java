package com.dbs.springbootjdbctemplate.apierror;

public abstract class ApiSubError {

}
